package com.rfandango.haku_x.overlay

import android.content.Context
import org.json.JSONObject
import java.io.File

/** How a control is drawn and how it takes touches. */
enum class ControlKind { FACE, GEM, PILL, STICK, DPAD, TRIGGER, CLICK, MENU }

/** The on-screen controller's controls, laid out like the original Xbox controller (the "Duke"). */
enum class ControlId(val kind: ControlKind, val label: String, val title: String) {
  A(ControlKind.FACE, "A", "A button"),
  B(ControlKind.FACE, "B", "B button"),
  X(ControlKind.FACE, "X", "X button"),
  Y(ControlKind.FACE, "Y", "Y button"),
  // The on-screen labels are LB/RB; they send the original Xbox white/black inputs.
  WHITE(ControlKind.PILL, "LB", "LB (original Xbox White button)"),
  BLACK(ControlKind.PILL, "RB", "RB (original Xbox Black button)"),
  BACK(ControlKind.PILL, "BACK", "Back"),
  START(ControlKind.PILL, "START", "Start"),
  LEFT_TRIGGER(ControlKind.TRIGGER, "LT", "Left trigger"),
  RIGHT_TRIGGER(ControlKind.TRIGGER, "RT", "Right trigger"),
  LEFT_STICK(ControlKind.STICK, "", "Left stick"),
  RIGHT_STICK(ControlKind.STICK, "", "Right stick"),
  LEFT_STICK_CLICK(ControlKind.CLICK, "LS", "Left stick click"),
  RIGHT_STICK_CLICK(ControlKind.CLICK, "RS", "Right stick click"),
  DPAD(ControlKind.DPAD, "", "D-pad"),
  MENU(ControlKind.MENU, "", "Menu"),
}

/**
 * One control's place on screen, in pixels of the overlay; radius is its
 * size, opacity how much of the game it hides (0.1-1).
 */
class ControlSpec(
  val id: ControlId,
  var cx: Float,
  var cy: Float,
  var radius: Float,
  var visible: Boolean = true,
  var opacity: Float = OverlayStore.DEFAULT_OPACITY,
) {
  fun copy() = ControlSpec(id, cx, cy, radius, visible, opacity)
}

/** All controls. */
class OverlayLayout(val controls: MutableMap<ControlId, ControlSpec>) {
  operator fun get(id: ControlId): ControlSpec = controls.getValue(id)
  fun copy() = OverlayLayout(controls.mapValuesTo(LinkedHashMap()) { it.value.copy() })
}

/**
 * The layout the user made, kept as a file in the app's storage so the
 * settings (main process) and the game (the core's process) read the same
 * one: positions as fractions of the overlay's width and height, sizes as
 * fractions of its height. Missing: the defaults for the screen at hand.
 */
object OverlayStore {
  private const val FILE = "overlay_layout.json"
  // One-time migration: install the new Xbox-on-phone default layout on existing installs.
  private const val VERSION = 3
  /** Half see-through: the game stays visible under the controls. */
  const val DEFAULT_OPACITY = 0.5f

  fun load(context: Context, w: Float, h: Float): OverlayLayout {
    val layout = defaults(w, h)
    val file = File(context.filesDir, FILE)
    if (!file.isFile) {
      return layout
    }
    try {
      val root = JSONObject(file.readText())
      if (root.optInt("version", 0) < VERSION) {
        // New default shoulder placement and integrated LS/RS labels. The next save writes v3.
        file.delete()
        return layout
      }
      val controls = root.optJSONObject("controls") ?: return layout
      for (id in ControlId.entries) {
        val c = controls.optJSONObject(id.name) ?: continue
        val spec = layout[id]
        spec.cx = (c.optDouble("x", (spec.cx / w).toDouble()).toFloat() * w).coerceIn(0f, w)
        spec.cy = (c.optDouble("y", (spec.cy / h).toDouble()).toFloat() * h).coerceIn(0f, h)
        spec.radius = (c.optDouble("r", (spec.radius / h).toDouble()).toFloat() * h).coerceIn(minRadius(h), maxRadius(h))
        spec.visible = id == ControlId.MENU || c.optBoolean("v", true)
        spec.opacity = c.optDouble("o", DEFAULT_OPACITY.toDouble()).toFloat().coerceIn(MIN_OPACITY, 1f)
      }
    } catch (_: Exception) {
      return defaults(w, h)
    }
    return layout
  }

  fun save(context: Context, layout: OverlayLayout, w: Float, h: Float) {
    val controls = JSONObject()
    for ((id, spec) in layout.controls) {
      controls.put(id.name, JSONObject().apply {
        put("x", (spec.cx / w).toDouble())
        put("y", (spec.cy / h).toDouble())
        put("r", (spec.radius / h).toDouble())
        put("v", spec.visible)
        put("o", spec.opacity.toDouble())
      })
    }
    val root = JSONObject().apply {
      put("version", VERSION)
      put("controls", controls)
    }
    val file = File(context.filesDir, FILE)
    val tmp = File(context.filesDir, "$FILE.tmp")
    tmp.writeText(root.toString())
    tmp.renameTo(file)
  }

  /** Back to the defaults (the file goes). */
  fun reset(context: Context) {
    File(context.filesDir, FILE).delete()
  }

  const val MIN_OPACITY = 0.1f
  fun minRadius(h: Float) = h * 0.025f
  fun maxRadius(h: Float) = h * 0.35f

  /**
   * The Duke's arrangement on a landscape screen: left stick up and left with
   * the D-pad below and inside it; the face buttons in two offset columns
   * (Y over X, B over A, the right column half a row lower) with white and
   * black above them; the right stick below and inside them; back, the jewel
   * (the menu) and start at the bottom centre; the triggers in the top corners.
   */
  fun defaults(w: Float, h: Float): OverlayLayout {
    val c = LinkedHashMap<ControlId, ControlSpec>()
    fun put(id: ControlId, x: Float, y: Float, r: Float, visible: Boolean = true) {
      c[id] = ControlSpec(id, x, y, r, visible = visible)
    }

    // Two-thumb landscape layout with space for the game in the middle.
    // Face buttons keep the original Xbox A/B/X/Y mapping; LB/RB use the
    // original controller's White/Black digital inputs, while LT/RT remain analog triggers.
    val face = h * 0.060f
    val sx = face * 2.15f
    val sy = face * 2.3f
    val fx = w - h * 0.27f
    val fy = h * 0.53f
    put(ControlId.Y, fx - sx / 2, fy - sy * 0.75f, face)
    put(ControlId.X, fx - sx / 2, fy + sy * 0.25f, face)
    put(ControlId.B, fx + sx / 2, fy - sy * 0.25f, face)
    put(ControlId.A, fx + sx / 2, fy + sy * 0.75f, face)

    // Shoulder controls are stacked at both upper corners, like the reference image.
    put(ControlId.LEFT_TRIGGER, h * 0.13f, h * 0.13f, h * 0.052f)
    put(ControlId.WHITE, h * 0.13f, h * 0.255f, h * 0.048f) // LB -> original White input
    put(ControlId.RIGHT_TRIGGER, w - h * 0.13f, h * 0.13f, h * 0.052f)
    put(ControlId.BLACK, w - h * 0.13f, h * 0.255f, h * 0.048f) // RB -> original Black input

    val leftStickX = h * 0.22f
    val leftStickY = h * 0.48f
    val rightStickX = w - h * 0.66f
    val rightStickY = h * 0.77f
    put(ControlId.LEFT_STICK, leftStickX, leftStickY, h * 0.105f)
    put(ControlId.RIGHT_STICK, rightStickX, rightStickY, h * 0.105f)
    // L3/R3 taps are handled on the center of the analog sticks; don't draw duplicate controls.
    put(ControlId.LEFT_STICK_CLICK, leftStickX, leftStickY, h * 0.040f, visible = false)
    put(ControlId.RIGHT_STICK_CLICK, rightStickX, rightStickY, h * 0.040f, visible = false)
    put(ControlId.DPAD, h * 0.40f, h * 0.76f, h * 0.095f)

    val pill = h * 0.043f
    put(ControlId.MENU, w / 2, h * 0.86f, h * 0.06f)
    put(ControlId.BACK, w / 2 - h * 0.13f, h * 0.91f, pill)
    put(ControlId.START, w / 2 + h * 0.13f, h * 0.91f, pill)
    return OverlayLayout(c)
  }
}
