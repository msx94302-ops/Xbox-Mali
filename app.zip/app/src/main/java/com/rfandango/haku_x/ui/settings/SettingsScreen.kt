package com.rfandango.haku_x.ui.settings

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.net.Uri
import android.text.format.DateFormat
import android.text.format.DateUtils
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ListItem
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.rfandango.haku_x.GpuDriverHelper
import com.rfandango.haku_x.NativeCoreActivity
import com.rfandango.haku_x.R
import com.rfandango.haku_x.data.AppPrefs
import com.rfandango.haku_x.data.Logs
import com.rfandango.haku_x.data.PreviousVersion
import com.rfandango.haku_x.data.Storage
import com.rfandango.haku_x.ui.common.ActionItem
import com.rfandango.haku_x.ui.common.ChoiceDialog
import com.rfandango.haku_x.ui.common.ConfirmDialog
import com.rfandango.haku_x.ui.common.DeleteButton
import com.rfandango.haku_x.ui.common.Hint
import com.rfandango.haku_x.ui.common.Section
import com.rfandango.haku_x.ui.common.SubScreen
import com.rfandango.haku_x.ui.common.SwitchItem
import com.rfandango.haku_x.ui.common.notify
import com.rfandango.haku_x.ui.theme.AppTheme
import com.rfandango.haku_x.ui.theme.appInDarkTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.GregorianCalendar
import kotlin.math.roundToInt

/** What the core reads at game start, plus the games folders the library scans. */
@Composable
fun SettingsScreen(
  onBack: () -> Unit,
  onEditControls: () -> Unit,
  onControllers: () -> Unit,
  onHardDisk: () -> Unit,
  onGpuDriver: () -> Unit,
  /** The first-start screen again: the xemu-based release's data brought over. */
  onMigrate: () -> Unit,
) {
  val context = LocalContext.current
  val prefs = remember { AppPrefs(context) }
  // the xemu-based release left its data here: its migration can run again
  val previous by produceState(false) { value = withContext(Dispatchers.IO) { PreviousVersion(context).find() != null } }
  val scope = rememberCoroutineScope()

  var folders by remember { mutableStateOf(prefs.gamesFolders) }
  var replacing by remember { mutableStateOf<Uri?>(null) }     /* the folder a pick replaces; null: adds */
  var removing by remember { mutableStateOf<Uri?>(null) }
  var category by rememberSaveable { mutableStateOf("graphics") }
  // Migrate older saved category names without losing the user's settings.
  val categoryShown = when (category) {
    "audio", "visual" -> "graphics"
    else -> category
  }
  var sidebarOpen by rememberSaveable { mutableStateOf(false) }
  var optimizer by remember { mutableStateOf(prefs.gpuOptimizerProfile) }
  var speedLimit by remember { mutableStateOf(prefs.speedLimitEnabled) }
  var speedPercent by remember { mutableIntStateOf(prefs.speedPercent) }
  var asyncShaders by remember { mutableStateOf(prefs.asyncShaders) }
  var prebuildShaders by remember { mutableStateOf(prefs.prebuildShaders) }
  var showFps by remember { mutableStateOf(prefs.showFps) }
  var scale by remember { mutableIntStateOf(prefs.renderScale) }
  var aspect by remember { mutableStateOf(prefs.aspectRatio) }
  var fxaa by remember { mutableStateOf(prefs.fxaa) }
  var upscale by remember { mutableStateOf(prefs.upscaleFilter) }
  var upscaleDialog by remember { mutableStateOf(false) }
  var format by remember { mutableStateOf(prefs.screenFormat) }
  var p480 by remember { mutableStateOf(prefs.video480p) }
  var p720 by remember { mutableStateOf(prefs.video720p) }
  var i1080 by remember { mutableStateOf(prefs.video1080i) }
  var pal60 by remember { mutableStateOf(prefs.pal60) }
  var avPack by remember { mutableStateOf(prefs.avPack) }
  var language by remember { mutableStateOf(prefs.language) }
  var languageDialog by remember { mutableStateOf(false) }
  var clockOffset by remember { mutableStateOf(prefs.clockOffset) }
  var clockDialog by remember { mutableStateOf(false) }
  var formatDialog by remember { mutableStateOf(false) }
  var cableDialog by remember { mutableStateOf(false) }
  var aspectDialog by remember { mutableStateOf(false) }
  val driver = remember { driverLabel(context) }       /* read again when back from its screen */
  var scaleDialog by remember { mutableStateOf(false) }
  val theme by AppTheme.mode.collectAsState()
  var themeDialog by remember { mutableStateOf(false) }
  val dark = appInDarkTheme()
  val customDrivers = remember { GpuDriverHelper.supportsCustomDriverLoading() }
  val chooseOptimizer: (String) -> Unit = { profile ->
    prefs.applyGpuOptimizerProfile(profile)
    optimizer = profile
    scale = prefs.renderScale
    speedLimit = prefs.speedLimitEnabled
    speedPercent = prefs.speedPercent
    asyncShaders = prefs.asyncShaders
    prebuildShaders = prefs.prebuildShaders
    fxaa = prefs.fxaa
    upscale = prefs.upscaleFilter
    publishRuntimeSettings(context, prefs)
  }
  val markOptimizerCustom: () -> Unit = {
    optimizer = AppPrefs.OPTIMIZER_CUSTOM
    prefs.gpuOptimizerProfile = AppPrefs.OPTIMIZER_CUSTOM
  }

  val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
    val old = replacing
    replacing = null
    if (uri != null) {
      Storage.persistPermission(context, uri)
      prefs.gamesFolders = if (old != null) folders.map { if (it == old) uri else it } else folders + uri
      folders = prefs.gamesFolders
      if (old != null && old !in folders) {
        Storage.releasePermission(context, old)
      }
    }
  }
  val snackbar = remember { SnackbarHostState() }
  /* The folder the logs' ZIP goes to (data/Logs.kt). */
  val pickLogsFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
    if (uri != null) {
      snackbar.notify(scope, context.getString(R.string.settings_export_logs_working))
      scope.launch {
        val name = withContext(Dispatchers.IO) { Logs.export(context, uri) }
        snackbar.notify(
          scope,
          if (name != null) context.getString(R.string.settings_export_logs_done, name)
          else context.getString(R.string.settings_export_logs_failed),
        )
      }
    }
  }
  val wideLayout = LocalConfiguration.current.screenWidthDp >= 760
  SubScreen(
    title = stringResource(R.string.settings_title),
    onBack = onBack,
    snackbar = snackbar,
    actions = {
      if (!wideLayout) {
        IconButton(onClick = { sidebarOpen = true }) {
          Icon(Icons.Filled.Menu, contentDescription = stringResource(R.string.settings_nav_open_menu))
        }
      }
    },
  ) { padding ->
    Box(Modifier.padding(padding).fillMaxSize()) {
      Row(
        Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        if (wideLayout) {
          SettingsSidebar(
            category = categoryShown,
            dark = dark,
            onSelect = { category = it },
            modifier = Modifier.width(248.dp),
          )
        }
        SettingsGlassPanel(
          category = categoryShown,
          dark = dark,
          modifier = Modifier.weight(1f).fillMaxHeight(),
        ) { activeCategory ->
          Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            if (activeCategory == "games") {
              Section(stringResource(R.string.settings_section_games))
              for (f in folders) {
                ListItem(
                  headlineContent = { Text(Storage.folderLabel(context, f)) },
                  supportingContent = { Text(Storage.folderPlace(context, f)) },
                  trailingContent = if (folders.size > 1) {
                    { DeleteButton(onClick = { removing = f }, description = stringResource(R.string.settings_games_folder_remove)) }
                  } else null,
                  modifier = Modifier.clickable {
                    replacing = f
                    pickFolder.launch(f)
                  },
                )
              }
              ActionItem(
                title = stringResource(R.string.settings_games_folder_add),
                summary = stringResource(R.string.settings_games_folder_add_desc),
                icon = Icons.Filled.Add,
              ) {
                replacing = null
                pickFolder.launch(folders.lastOrNull())
              }
            }

            if (activeCategory == "controls") {
              Section(stringResource(R.string.settings_section_controls))
              ListItem(
                headlineContent = { Text(stringResource(R.string.settings_overlay)) },
                supportingContent = { Text(stringResource(R.string.settings_overlay_desc)) },
                modifier = Modifier.clickable(onClick = onEditControls),
              )
              ListItem(
                headlineContent = { Text(stringResource(R.string.controllers_title)) },
                supportingContent = { Text(stringResource(R.string.controllers_settings_desc)) },
                modifier = Modifier.clickable(onClick = onControllers),
              )
            }

            if (activeCategory == "graphics") {
              Section(stringResource(R.string.settings_section_display))
              ListItem(
                headlineContent = { Text(stringResource(R.string.settings_theme)) },
                supportingContent = { Text(stringResource(themeLabel(theme))) },
                modifier = Modifier.clickable { themeDialog = true },
              )
              ListItem(
                headlineContent = { Text(stringResource(R.string.settings_aspect)) },
                supportingContent = {
                  Text(stringResource(aspectLabel(aspect)) + ". " + stringResource(R.string.settings_applies_next_start))
                },
                modifier = Modifier.clickable { aspectDialog = true },
              )
              SwitchItem(
                title = stringResource(R.string.settings_show_fps),
                summary = stringResource(R.string.settings_show_fps_desc),
                checked = showFps,
                onChange = { showFps = it; prefs.showFps = it },
              )
              Section(stringResource(R.string.settings_section_console_video))
              Hint(stringResource(R.string.settings_console_video_desc))
              ListItem(
                headlineContent = { Text(stringResource(R.string.settings_screen_format)) },
                supportingContent = { Text(stringResource(formatLabel(format))) },
                modifier = Modifier.clickable { formatDialog = true },
              )
              SwitchItem(
                title = stringResource(R.string.settings_480p),
                summary = stringResource(R.string.settings_480p_desc),
                checked = p480,
                onChange = { p480 = it; prefs.video480p = it },
              )
              SwitchItem(
                title = stringResource(R.string.settings_720p),
                summary = stringResource(R.string.settings_720p_desc),
                checked = p720,
                onChange = { p720 = it; prefs.video720p = it },
              )
              SwitchItem(
                title = stringResource(R.string.settings_1080i),
                summary = stringResource(R.string.settings_1080i_desc),
                checked = i1080,
                onChange = { i1080 = it; prefs.video1080i = it },
              )
              SwitchItem(
                title = stringResource(R.string.settings_pal60),
                summary = stringResource(R.string.settings_pal60_desc),
                checked = pal60,
                onChange = { pal60 = it; prefs.pal60 = it },
              )
              ListItem(
                headlineContent = { Text(stringResource(R.string.settings_av_cable)) },
                supportingContent = { Text(stringResource(cableLabel(avPack))) },
                modifier = Modifier.clickable { cableDialog = true },
              )
            }

            if (activeCategory == "performance") {
              Section(stringResource(R.string.settings_nav_performance))
              SwitchItem(
                title = stringResource(R.string.settings_speed_limit),
                summary = stringResource(R.string.settings_speed_limit_desc),
                checked = speedLimit,
                onChange = {
                  speedLimit = it
                  prefs.speedLimitEnabled = it
                  markOptimizerCustom()
                  publishRuntimeSettings(context, prefs)
                },
              )
              Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                Text(stringResource(R.string.settings_speed_percent_value, speedPercent))
                Slider(
                  value = speedPercent.toFloat(),
                  onValueChange = { speedPercent = (it / 10f).roundToInt() * 10 },
                  onValueChangeFinished = {
                    prefs.speedPercent = speedPercent
                    markOptimizerCustom()
                    publishRuntimeSettings(context, prefs)
                  },
                  valueRange = 0f..400f,
                  steps = 39,
                  enabled = speedLimit,
                )
                Text(
                  stringResource(R.string.settings_speed_percent_desc),
                  style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                )
              }
            }

            if (activeCategory == "profiles") {
              Section(stringResource(R.string.settings_optimizer_title))
              Text(
                stringResource(R.string.settings_optimizer_desc),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
              )
              Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                FilterChip(optimizer == AppPrefs.OPTIMIZER_NORMAL, { chooseOptimizer(AppPrefs.OPTIMIZER_NORMAL) }, label = { Text(stringResource(R.string.settings_optimizer_normal)) })
                FilterChip(optimizer == AppPrefs.OPTIMIZER_BALANCED, { chooseOptimizer(AppPrefs.OPTIMIZER_BALANCED) }, label = { Text(stringResource(R.string.settings_optimizer_balanced)) })
                FilterChip(optimizer == AppPrefs.OPTIMIZER_AGGRESSIVE, { chooseOptimizer(AppPrefs.OPTIMIZER_AGGRESSIVE) }, label = { Text(stringResource(R.string.settings_optimizer_aggressive)) })
              }
              Text(
                stringResource(when (optimizer) {
                  AppPrefs.OPTIMIZER_NORMAL -> R.string.settings_optimizer_normal_desc
                  AppPrefs.OPTIMIZER_AGGRESSIVE -> R.string.settings_optimizer_aggressive_desc
                  AppPrefs.OPTIMIZER_CUSTOM -> R.string.settings_optimizer_custom_desc
                  else -> R.string.settings_optimizer_balanced_desc
                }),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
              )
            }

            if (activeCategory == "optimizer") {
              Section(stringResource(R.string.settings_section_graphics))
              ListItem(
                headlineContent = { Text(stringResource(R.string.settings_scale)) },
                supportingContent = {
                  Text(stringResource(R.string.settings_scale_value, scale) + ". " + stringResource(R.string.settings_applies_next_start))
                },
                modifier = Modifier.clickable { scaleDialog = true },
              )
              SwitchItem(
                title = stringResource(R.string.settings_fxaa),
                summary = stringResource(R.string.settings_fxaa_desc) + " " + stringResource(R.string.settings_applies_next_start),
                checked = fxaa,
                onChange = { fxaa = it; prefs.fxaa = it; markOptimizerCustom() },
              )
              ListItem(
                headlineContent = { Text(stringResource(R.string.settings_upscale)) },
                supportingContent = {
                  Text(stringResource(upscaleLabel(upscale)) + ". " + stringResource(R.string.settings_upscale_desc) + " " + stringResource(R.string.settings_applies_next_start))
                },
                modifier = Modifier.clickable { upscaleDialog = true },
              )
              SwitchItem(
                title = stringResource(R.string.settings_async_shaders),
                summary = stringResource(R.string.settings_async_shaders_desc) + " " + stringResource(R.string.settings_applies_next_start),
                checked = asyncShaders,
                onChange = { asyncShaders = it; prefs.asyncShaders = it; markOptimizerCustom() },
              )
              SwitchItem(
                title = stringResource(R.string.settings_prebuild_shaders),
                summary = stringResource(R.string.settings_prebuild_shaders_desc) + " " + stringResource(R.string.settings_applies_next_start),
                checked = prebuildShaders,
                onChange = { prebuildShaders = it; prefs.prebuildShaders = it; markOptimizerCustom() },
              )
            }

            if (activeCategory == "panvk") {
              Hint(stringResource(R.string.gpu_driver_desc))
              Section(stringResource(R.string.settings_nav_panvk))
              ListItem(
                headlineContent = { Text(stringResource(R.string.settings_gpu_driver_title)) },
                supportingContent = {
                  Text(if (customDrivers) driver else stringResource(R.string.settings_gpu_driver_not_supported))
                },
                leadingContent = {
                  Icon(Icons.Filled.Build, contentDescription = null)
                },
                modifier = Modifier.clickable(enabled = customDrivers, onClick = onGpuDriver),
              )
              if (!customDrivers) {
                Hint(stringResource(R.string.settings_gpu_driver_not_supported))
              }
            }

            if (activeCategory == "system") {
              Section(stringResource(R.string.settings_section_console))
              ListItem(
                headlineContent = { Text(stringResource(R.string.hdd_title)) },
                supportingContent = { Text(stringResource(R.string.hdd_settings_desc)) },
                modifier = Modifier.clickable(onClick = onHardDisk),
              )
              if (previous) {
                ListItem(
                  headlineContent = { Text(stringResource(R.string.settings_migrate)) },
                  supportingContent = { Text(stringResource(R.string.settings_migrate_desc)) },
                  modifier = Modifier.clickable(onClick = onMigrate),
                )
              }
              ListItem(
                headlineContent = { Text(stringResource(R.string.settings_language)) },
                supportingContent = {
                  Text(languageLabel(language) + ". " + stringResource(R.string.settings_language_desc))
                },
                modifier = Modifier.clickable { languageDialog = true },
              )
              ListItem(
                headlineContent = { Text(stringResource(R.string.settings_clock)) },
                supportingContent = { Text(clockLabel(clockOffset) + ". " + stringResource(R.string.settings_clock_desc)) },
                modifier = Modifier.clickable { clockDialog = true },
              )
              Section(stringResource(R.string.settings_section_logs))
              ListItem(
                headlineContent = { Text(stringResource(R.string.settings_export_logs)) },
                supportingContent = { Text(stringResource(R.string.settings_export_logs_desc)) },
                modifier = Modifier.clickable { pickLogsFolder.launch(null) },
              )
            }
          }
        }
      }

      if (!wideLayout) {
        if (sidebarOpen) {
          Box(
            Modifier.fillMaxSize()
              .background(Color.Black.copy(alpha = 0.42f))
              .clickable { sidebarOpen = false }
              .zIndex(1f),
          )
        }
        AnimatedVisibility(
          visible = sidebarOpen,
          modifier = Modifier.align(Alignment.CenterStart).zIndex(2f),
          enter = slideInHorizontally(initialOffsetX = { -it }) + fadeIn(),
          exit = slideOutHorizontally(targetOffsetX = { -it }) + fadeOut(),
        ) {
          SettingsSidebar(
            category = categoryShown,
            dark = dark,
            onSelect = {
              category = it
              sidebarOpen = false
            },
            modifier = Modifier.width(280.dp),
          )
        }
      }
    }
  }
  if (languageDialog) {
    ChoiceDialog(
      title = stringResource(R.string.settings_language),
      options = LANGUAGES.map { it to languageLabel(it) },
      current = language,
      onPick = { language = it; prefs.language = it; languageDialog = false },
      onDismiss = { languageDialog = false },
    )
  }
  if (clockDialog) {
    ChoiceDialog(
      title = stringResource(R.string.settings_clock),
      options = listOf(false to stringResource(R.string.settings_clock_phone),
                       true to stringResource(R.string.settings_clock_set_pick)),
      current = clockOffset != null,
      onPick = { set ->
        clockDialog = false
        if (set) {
          pickClock(context, dark, System.currentTimeMillis() + (clockOffset ?: 0L)) {
            clockOffset = it - System.currentTimeMillis()
            prefs.clockOffset = clockOffset
          }
        } else {
          clockOffset = null
          prefs.clockOffset = null
        }
      },
      onDismiss = { clockDialog = false },
    )
  }
  if (formatDialog) {
    ChoiceDialog(
      title = stringResource(R.string.settings_screen_format),
      options = FORMATS.map { it to stringResource(formatLabel(it)) },
      current = format,
      onPick = { format = it; prefs.screenFormat = it; formatDialog = false },
      onDismiss = { formatDialog = false },
    )
  }
  if (cableDialog) {
    ChoiceDialog(
      title = stringResource(R.string.settings_av_cable),
      options = CABLES.map { it to stringResource(cableLabel(it)) },
      current = avPack,
      onPick = { avPack = it; prefs.avPack = it; cableDialog = false },
      onDismiss = { cableDialog = false },
    )
  }
  if (aspectDialog) {
    ChoiceDialog(
      title = stringResource(R.string.settings_aspect),
      options = ASPECTS.map { it to stringResource(aspectLabel(it)) },
      current = aspect,
      onPick = { aspect = it; prefs.aspectRatio = it; aspectDialog = false },
      onDismiss = { aspectDialog = false },
    )
  }
  if (upscaleDialog) {
    ChoiceDialog(
      title = stringResource(R.string.settings_upscale),
      options = UPSCALERS.map { it to stringResource(upscaleLabel(it)) },
      current = upscale,
      onPick = { upscale = it; prefs.upscaleFilter = it; markOptimizerCustom(); upscaleDialog = false },
      onDismiss = { upscaleDialog = false },
    )
  }
  if (scaleDialog) {
    ChoiceDialog(
      title = stringResource(R.string.settings_scale),
      options = SCALES.map { it to scaleLabel(it) },
      current = scale,
      onPick = { scale = it; prefs.renderScale = it; markOptimizerCustom(); scaleDialog = false },
      onDismiss = { scaleDialog = false },
    )
  }
  if (themeDialog) {
    ChoiceDialog(
      title = stringResource(R.string.settings_theme),
      options = THEMES.map { it to stringResource(themeLabel(it)) },
      current = theme,
      onPick = { AppTheme.set(context, it); themeDialog = false },
      onDismiss = { themeDialog = false },
    )
  }
  removing?.let { f ->
    ConfirmDialog(
      title = stringResource(R.string.settings_games_folder_remove),
      text = stringResource(R.string.settings_games_folder_remove_text, Storage.folderPlace(context, f)),
      confirm = stringResource(R.string.settings_games_folder_remove_confirm),
      onConfirm = {
        prefs.gamesFolders = folders - f
        folders = prefs.gamesFolders
        Storage.releasePermission(context, f)
        removing = null
      },
      onDismiss = { removing = null },
    )
  }
}

/** A translucent navigation panel inspired by the Xbox Mali concept screen. */
@Composable
private fun SettingsSidebar(
  category: String,
  dark: Boolean,
  onSelect: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val shape = RoundedCornerShape(28.dp)
  val neonGreen = Color(0xFF00F58A)
  val neonCyan = Color(0xFF16DDF2)
  val foreground = if (dark) Color(0xFFF5FAFF) else Color(0xFF0B1B2B)
  val secondary = if (dark) Color(0xFFADC2D8) else Color(0xFF5C7084)
  val glass = if (dark) {
    Brush.linearGradient(listOf(Color(0xED071321), Color(0xE80A2230), Color(0xEE07101F)))
  } else {
    Brush.linearGradient(listOf(Color(0xF7FFFFFF), Color(0xF2EAF5F7), Color(0xF7FFFFFF)))
  }
  Column(
    modifier = modifier.fillMaxHeight()
      .clip(shape)
      .background(glass, shape)
      .border(1.dp, if (dark) Color(0x5572F39A) else Color(0x5525B881), shape)
      .padding(12.dp)
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.spacedBy(5.dp),
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 6.dp),
    ) {
      Image(
        painter = painterResource(R.drawable.logo_xbox),
        contentDescription = null,
        modifier = Modifier.size(42.dp).clip(CircleShape),
      )
      Column(Modifier.weight(1f)) {
        Text("Xbox Mali", color = foreground, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(
          stringResource(R.string.settings_nav_tagline),
          color = secondary,
          fontSize = 10.sp,
          lineHeight = 13.sp,
        )
      }
    }
    Spacer(Modifier.height(2.dp))
    Box(
      Modifier.fillMaxWidth().height(2.dp)
        .background(Brush.horizontalGradient(listOf(neonGreen, neonCyan, Color.Transparent))),
    )
    Text(
      stringResource(R.string.settings_nav_section_title),
      color = secondary,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = 1.1.sp,
      modifier = Modifier.padding(start = 8.dp, top = 8.dp, bottom = 3.dp),
    )
    SettingsSidebarItem(
      title = stringResource(R.string.settings_nav_graphics),
      summary = stringResource(R.string.settings_nav_graphics_desc),
      icon = Icons.Filled.Settings,
      selected = category == "graphics",
      dark = dark,
      onClick = { onSelect("graphics") },
    )
    SettingsSidebarItem(
      title = stringResource(R.string.settings_nav_performance),
      summary = stringResource(R.string.settings_nav_performance_desc),
      icon = Icons.Filled.PlayArrow,
      selected = category == "performance",
      dark = dark,
      onClick = { onSelect("performance") },
    )
    SettingsSidebarItem(
      title = stringResource(R.string.settings_nav_profiles),
      summary = stringResource(R.string.settings_nav_profiles_desc),
      icon = Icons.Filled.Star,
      selected = category == "profiles",
      dark = dark,
      onClick = { onSelect("profiles") },
    )
    SettingsSidebarItem(
      title = stringResource(R.string.settings_nav_optimizer),
      summary = stringResource(R.string.settings_nav_optimizer_desc),
      icon = Icons.Filled.Build,
      selected = category == "optimizer",
      dark = dark,
      onClick = { onSelect("optimizer") },
    )
    SettingsSidebarItem(
      title = stringResource(R.string.settings_nav_panvk),
      summary = stringResource(R.string.settings_nav_panvk_desc),
      icon = Icons.Filled.Build,
      selected = category == "panvk",
      dark = dark,
      onClick = { onSelect("panvk") },
    )
    SettingsSidebarItem(
      title = stringResource(R.string.settings_nav_system),
      summary = stringResource(R.string.settings_nav_system_desc),
      icon = Icons.Filled.Info,
      selected = category == "system",
      dark = dark,
      onClick = { onSelect("system") },
    )
    HorizontalDivider(
      modifier = Modifier.padding(vertical = 8.dp),
      color = if (dark) Color.White.copy(alpha = 0.12f) else Color.Black.copy(alpha = 0.09f),
    )
    Text(
      stringResource(R.string.settings_nav_other_title),
      color = secondary,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = 1.1.sp,
      modifier = Modifier.padding(start = 8.dp, bottom = 3.dp),
    )
    SettingsSidebarItem(
      title = stringResource(R.string.settings_nav_library),
      summary = stringResource(R.string.settings_nav_library_desc),
      icon = Icons.Filled.Home,
      selected = category == "games",
      dark = dark,
      onClick = { onSelect("games") },
    )
    SettingsSidebarItem(
      title = stringResource(R.string.settings_nav_controls),
      summary = stringResource(R.string.settings_nav_controls_desc),
      icon = Icons.Filled.Settings,
      selected = category == "controls",
      dark = dark,
      onClick = { onSelect("controls") },
    )
  }
}

@Composable
private fun SettingsSidebarItem(
  title: String,
  summary: String,
  icon: ImageVector,
  selected: Boolean,
  dark: Boolean,
  onClick: () -> Unit,
) {
  val shape = RoundedCornerShape(17.dp)
  val neonGreen = Color(0xFF00F58A)
  val neonCyan = Color(0xFF16DDF2)
  val foreground = if (dark) Color(0xFFF5FAFF) else Color(0xFF102033)
  val muted = if (dark) Color(0xFFB5C7DA) else Color(0xFF5D7185)
  val fill = if (selected) {
    Brush.linearGradient(listOf(Color(0xFF00A96A), Color(0xFF008F9C)))
  } else {
    Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
  }
  Row(
    modifier = Modifier.fillMaxWidth()
      .clip(shape)
      .background(fill, shape)
      .border(
        if (selected) 1.dp else 0.5.dp,
        if (selected) Brush.linearGradient(listOf(neonGreen.copy(alpha = 0.95f), neonCyan.copy(alpha = 0.75f)))
        else Brush.linearGradient(listOf((if (dark) Color.White else Color.Black).copy(alpha = 0.07f), Color.Transparent)),
        shape,
      )
      .clickable(onClick = onClick)
      .padding(horizontal = 9.dp, vertical = 9.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Box(
      modifier = Modifier.size(42.dp)
        .clip(CircleShape)
        .background(if (selected) Color.White.copy(alpha = 0.16f) else neonGreen.copy(alpha = if (dark) 0.10f else 0.08f)),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = if (selected) Color.White else if (dark) neonCyan else Color(0xFF069B6A),
        modifier = Modifier.size(27.dp),
      )
    }
    Column(Modifier.weight(1f)) {
      Text(
        title,
        color = if (selected) Color.White else foreground,
        fontSize = 14.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
        maxLines = 1,
      )
      Text(
        summary,
        color = if (selected) Color.White.copy(alpha = 0.82f) else muted,
        fontSize = 10.sp,
        lineHeight = 13.sp,
        maxLines = 2,
      )
    }
  }
}

/** Glass-style content surface with a short horizontal/fade transition between categories. */
@Composable
private fun SettingsGlassPanel(
  category: String,
  dark: Boolean,
  modifier: Modifier = Modifier,
  content: @Composable (String) -> Unit,
) {
  val shape = RoundedCornerShape(28.dp)
  val neonGreen = Color(0xFF00E88B)
  val neonCyan = Color(0xFF16DDF2)
  val foreground = if (dark) Color(0xFFF5FAFF) else Color(0xFF122235)
  val secondary = if (dark) Color(0xFFABC1D8) else Color(0xFF5A7085)
  val glass = if (dark) {
    Brush.linearGradient(listOf(Color(0xF5071424), Color(0xF50A2030), Color(0xF5071020)))
  } else {
    Brush.linearGradient(listOf(Color(0xF9FFFFFF), Color(0xF1F0F7FA), Color(0xF8FFFFFF)))
  }
  Column(
    modifier = modifier.clip(shape)
      .background(glass, shape)
      .border(1.dp, if (dark) Color(0x5572F39A) else Color(0x4425B881), shape)
      .padding(horizontal = 12.dp, vertical = 10.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(start = 5.dp, end = 5.dp, top = 4.dp, bottom = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Column(Modifier.weight(1f)) {
        Text(
          stringResource(settingsCategoryTitle(category)),
          color = foreground,
          fontSize = 22.sp,
          fontWeight = FontWeight.Bold,
          lineHeight = 27.sp,
        )
        Text(
          stringResource(settingsCategoryDescription(category)),
          color = secondary,
          fontSize = 12.sp,
          lineHeight = 16.sp,
        )
      }
      Box(
        modifier = Modifier.size(48.dp)
          .clip(CircleShape)
          .background(Brush.linearGradient(listOf(neonGreen.copy(alpha = 0.17f), neonCyan.copy(alpha = 0.12f))), CircleShape)
          .border(1.dp, Brush.linearGradient(listOf(neonGreen.copy(alpha = 0.75f), neonCyan.copy(alpha = 0.7f))), CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          settingsCategoryIcon(category),
          contentDescription = null,
          tint = if (dark) neonGreen else Color(0xFF079965),
          modifier = Modifier.size(29.dp),
        )
      }
    }
    HorizontalDivider(color = if (dark) neonCyan.copy(alpha = 0.2f) else neonGreen.copy(alpha = 0.3f))
    AnimatedContent(
      targetState = category,
      modifier = Modifier.weight(1f).fillMaxWidth().padding(top = 4.dp),
      transitionSpec = {
        (slideInHorizontally(initialOffsetX = { it / 12 }) + fadeIn()) togetherWith
          (slideOutHorizontally(targetOffsetX = { -it / 12 }) + fadeOut())
      },
      label = "xbox-mali-settings-transition",
    ) { targetCategory -> content(targetCategory) }
  }
}

private fun settingsCategoryTitle(category: String): Int = when (category) {
  "performance" -> R.string.settings_nav_performance
  "profiles" -> R.string.settings_nav_profiles
  "optimizer" -> R.string.settings_nav_optimizer
  "panvk" -> R.string.settings_nav_panvk
  "system" -> R.string.settings_nav_system
  "games" -> R.string.settings_nav_library
  "controls" -> R.string.settings_nav_controls
  else -> R.string.settings_nav_graphics
}

private fun settingsCategoryDescription(category: String): Int = when (category) {
  "performance" -> R.string.settings_nav_performance_desc
  "profiles" -> R.string.settings_nav_profiles_desc
  "optimizer" -> R.string.settings_nav_optimizer_desc
  "panvk" -> R.string.settings_nav_panvk_desc
  "system" -> R.string.settings_nav_system_desc
  "games" -> R.string.settings_nav_library_desc
  "controls" -> R.string.settings_nav_controls_desc
  else -> R.string.settings_nav_graphics_desc
}

private fun settingsCategoryIcon(category: String): ImageVector = when (category) {
  "performance" -> Icons.Filled.PlayArrow
  "profiles" -> Icons.Filled.Star
  "optimizer", "panvk" -> Icons.Filled.Build
  "system" -> Icons.Filled.Info
  "games" -> Icons.Filled.Home
  else -> Icons.Filled.Settings
}

/** The app's themes: the phone's, light, dark. */
private val THEMES = listOf(AppPrefs.THEME_SYSTEM, AppPrefs.THEME_LIGHT, AppPrefs.THEME_DARK)

private fun themeLabel(value: String) = when (value) {
  AppPrefs.THEME_LIGHT -> R.string.settings_theme_light
  AppPrefs.THEME_DARK -> R.string.settings_theme_dark
  else -> R.string.settings_theme_system
}

/** The render scales: native, then 2x to 4x. */
internal val SCALES = (1..4).toList()

@Composable
internal fun scaleLabel(value: Int) = when (value) {
  1 -> stringResource(R.string.settings_scale_native)
  2 -> stringResource(R.string.settings_scale_2x)
  3 -> stringResource(R.string.settings_scale_3x)
  else -> stringResource(R.string.settings_scale_4x)
}

internal val ASPECTS = listOf("auto", "4:3", "16:9", "stretch")

internal val UPSCALERS = listOf(NativeCoreActivity.UPSCALE_BILINEAR, NativeCoreActivity.UPSCALE_NEAREST)
internal val FORMATS = listOf(AppPrefs.FORMAT_NORMAL, AppPrefs.FORMAT_LETTERBOX, AppPrefs.FORMAT_WIDESCREEN)
internal val CABLES = listOf(AppPrefs.AV_HDTV, AppPrefs.AV_STANDARD, AppPrefs.AV_SVIDEO)
internal val LANGUAGES = listOf(AppPrefs.LANG_AUTO) + AppPrefs.XBOX_LANGUAGES

/* Each language in its own words, as the dashboard lists them. */
private val LANGUAGE_NAMES = mapOf(
  "en" to "English",
  "ja" to "日本語",
  "de" to "Deutsch",
  "fr" to "Français",
  "es" to "Español",
  "it" to "Italiano",
  "ko" to "한국어",
  "zh" to "中文（繁體）",
  "pt" to "Português",
)

@Composable
internal fun languageLabel(value: String) =
  if (value == AppPrefs.LANG_AUTO) {
    stringResource(R.string.settings_language_auto, LANGUAGE_NAMES.getValue(AppPrefs.autoLanguage()))
  } else {
    LANGUAGE_NAMES[value] ?: value
  }

/** The console's clock: the phone's time, or the time set by hand it shows now. */
@Composable
private fun clockLabel(offset: Long?) =
  if (offset == null) {
    stringResource(R.string.settings_clock_phone)
  } else {
    val now = System.currentTimeMillis() + offset
    stringResource(
      R.string.settings_clock_set,
      DateUtils.formatDateTime(
        LocalContext.current, now,
        DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_YEAR or DateUtils.FORMAT_SHOW_TIME,
      ),
    )
  }

/**
 * The console's date (2001-2099), then its time, from the given moment (ms), in the phone's own
 * pickers (they fit a landscape screen), light or dark as the app is; onSet gets the moment picked.
 */
private fun pickClock(context: Context, dark: Boolean, from: Long, onSet: (Long) -> Unit) {
  val c = Calendar.getInstance().apply { timeInMillis = from }
  val style = if (dark) R.style.Theme_HakuX_Picker_Dark else R.style.Theme_HakuX_Picker
  val date = DatePickerDialog(context, style, { _, year, month, day ->
    TimePickerDialog(context, style, { _, hour, minute ->
      c.set(year, month, day, hour, minute, 0)
      c.set(Calendar.MILLISECOND, 0)
      onSet(c.timeInMillis)
    }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), DateFormat.is24HourFormat(context)).show()
  }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
  date.datePicker.minDate = GregorianCalendar(2001, Calendar.JANUARY, 1).timeInMillis
  date.datePicker.maxDate = GregorianCalendar(2099, Calendar.DECEMBER, 31).timeInMillis
  date.show()
}

internal fun formatLabel(value: String) = when (value) {
  AppPrefs.FORMAT_LETTERBOX -> R.string.settings_format_letterbox
  AppPrefs.FORMAT_WIDESCREEN -> R.string.settings_format_widescreen
  else -> R.string.settings_format_normal
}

internal fun cableLabel(value: String) = when (value) {
  AppPrefs.AV_STANDARD -> R.string.settings_av_standard
  AppPrefs.AV_SVIDEO -> R.string.settings_av_svideo
  else -> R.string.settings_av_hdtv
}

internal fun upscaleLabel(value: String) = when (value) {
  NativeCoreActivity.UPSCALE_NEAREST -> R.string.settings_upscale_nearest
  else -> R.string.settings_upscale_bilinear
}

internal fun aspectLabel(value: String) = when (value) {
  "4:3" -> R.string.settings_aspect_4_3
  "16:9" -> R.string.settings_aspect_16_9
  "stretch" -> R.string.settings_aspect_stretch
  else -> R.string.settings_aspect_auto
}

/** The driver in use, for the settings' GPU driver item (its version, when its package names one). */
private fun driverLabel(context: android.content.Context): String {
  GpuDriverHelper.init(context)
  if (!GpuDriverHelper.supportsCustomDriverLoading()) {
    return context.getString(R.string.settings_gpu_driver_not_supported)
  }
  val d = GpuDriverHelper.getActiveDriver() ?: return context.getString(R.string.settings_gpu_driver_system)
  val name = d.name ?: context.getString(R.string.settings_gpu_driver_custom)
  return d.driverVersion?.let { context.getString(R.string.settings_gpu_driver_active_version, name, it) } ?: name
}


/** Notify an active game's native-process activity; preferences still persist for the next launch. */
private fun publishRuntimeSettings(context: Context, prefs: AppPrefs) {
  context.sendBroadcast(
    android.content.Intent(NativeCoreActivity.ACTION_RUNTIME_PREFS_CHANGED)
      .setPackage(context.packageName)
      .putExtra(NativeCoreActivity.EXTRA_RUNTIME_AUDIO_VOLUME, prefs.audioVolume)
      .putExtra(NativeCoreActivity.EXTRA_RUNTIME_SPEED_LIMIT, prefs.speedLimitEnabled)
      .putExtra(NativeCoreActivity.EXTRA_RUNTIME_SPEED_PERCENT, prefs.speedPercent),
  )
}
