package com.rfandango.haku_x

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.VideoView

class SplashActivity : Activity() {
    private var opened = false
    private lateinit var video: VideoView
  private var sourceWidth = 640
  private var sourceHeight = 360

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        hideSystemBars()

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            clipChildren = true
            clipToPadding = true
        }

        video = object : VideoView(this) {
      override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = View.MeasureSpec.getSize(widthMeasureSpec)
        val h = View.MeasureSpec.getSize(heightMeasureSpec)
        if (w > 0 && h > 0) {
          val scale = minOf(w.toFloat() / sourceWidth, h.toFloat() / sourceHeight)
          setMeasuredDimension(
            (sourceWidth * scale).toInt(),
            (sourceHeight * scale).toInt()
          )
        } else {
          setMeasuredDimension(w, h)
        }
      }
    }.apply {
            setVideoURI(
                Uri.parse("android.resource://$packageName/${R.raw.xbox_mali_intro}")
            )

            setOnCompletionListener { openLibrary() }
            setOnErrorListener { _, _, _ ->
                openLibrary()
                true
            }
            setOnPreparedListener { player ->
        player.isLooping = false
        sourceWidth = player.videoWidth.coerceAtLeast(1)
        sourceHeight = player.videoHeight.coerceAtLeast(1)
        requestLayout()
        start()
      }
        }

        root.addView(
            video,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
        )

        val skip = TextView(this).apply {
            text = getString(R.string.splash_skip)
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(0x990B2413.toInt())
            contentDescription = getString(R.string.splash_skip)
            setOnClickListener { openLibrary() }
        }

        root.addView(
            skip,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.END
            ).apply {
                setMargins(0, 0, dp(18), dp(18))
            }
        )

        setContentView(root)
    }

    private fun openLibrary() {
        if (opened) return
        opened = true
        runCatching { video.stopPlayback() }

        startActivity(
            Intent(this, LauncherActivity::class.java).apply {
                action = Intent.ACTION_MAIN
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
        )
        finish()

        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }

    override fun onBackPressed() {
        openLibrary()
    }
}
